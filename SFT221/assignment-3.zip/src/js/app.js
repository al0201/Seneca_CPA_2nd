/**
 * WEB222 – Assignment 3
 *
 * I declare that this assignment is my own work in accordance with
 * Seneca Academic Policy. No part of this assignment has been
 * copied manually or electronically from any other source
 * (including web sites) or distributed to other students.
 *
 * Please update the following with your information:
 *
 *      Name:       Ahram Lee
 *      Student ID: alee239 / 133849232
 *      Date:       2024-07-15
 */

// All of our data is available on the global `window` object.
// Create local variables to work with it in this file.
const { artists, songs } = window;

// For debugging, display all of our data in the console. You can remove this later.
console.log({ artists, songs }, "Song and Artist App Data");

// DOM elements
const menu = document.getElementById("menu");
const selectedArtist = document.getElementById("selected-artist");
const songsTable = document.getElementById("songs");

// Function to display songs by the selected artist
function displaySongsByArtist(artistId) {
  songsTable.innerHTML = ""; // Clear previous songs

  const filteredSongs = songs.filter((song) => song.artistId === artistId);

  filteredSongs.forEach((song) => {
    const row = document.createElement("tr");

    row.innerHTML = `
      <td>${song.title}</td>
      <td>${song.released}</td>
      <td>${song.duration} sec</td>
      <td><a href="${song.mediaUrl}" target="_blank">Listen</a></td>
      <td>${song.explicitLyrics ? "Yes" : "No"}</td>
    `;

    songsTable.appendChild(row);
  });
}

// Function to create artist buttons
function createArtistButtons() {
  artists.forEach((artist) => {
    const button = document.createElement("button");
    button.textContent = artist.name;
    button.addEventListener("click", () => {
      displaySongsByArtist(artist.artistId);
      selectedArtist.textContent = artist.name;
    });
    menu.appendChild(button);
  });

  // Display the first artist's songs by default
  if (artists.length > 0) {
    displaySongsByArtist(artists[0].artistId);
    selectedArtist.textContent = artists[0].name;
  }
}

// Initialize the app
createArtistButtons();
